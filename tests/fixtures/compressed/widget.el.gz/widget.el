(defun widget-size (size)
  (* size 2))
